# SuperNess Lib

[![](https://avatars2.githubusercontent.com/u/2029111?s=30)LuizaLabs](https://medium.com/luizalabs)

SuperNess is the lib that support the (data) Lake Ness. This lib is meant to be the abstraction of reading, writing and utils methods for pyspark ETLs running on the SNess Platform.

